import MainSeaction from "./components/MainSeaction";
import NavBar from "./components/NavBar";
import { useState, useEffect, useMemo } from "react";
import axios from "axios";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import CartSetion from "./components/CartSetion";

function App() {
  const [products, setProducts] = useState([]);
  const [displayedPro, setDisplayedPro] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [cartItems, setCartItems] = useState([]);
  const sumPrice = useMemo(() => {
    let sum = 0;
    for (let i = 0; i < cartItems.length; i++)
      sum += cartItems[i].price * cartItems[i].qty;
    return sum.toFixed(2);
  }, [cartItems]);

  useEffect(() => {
    const productHandler = (list) => {
      const updatedProducts = list.map((item) => ({
        id: item.id,
        title: item.title,
        price: item.price,
        category: item.category,
        image: item.image,
        qty: 0,
      }));
      setProducts([...products, ...updatedProducts]);
      setDisplayedPro([...displayedPro, ...updatedProducts]);
    };
    axios
      .get(`https://fakestoreapi.com/products`)
      .then((response) => {
        productHandler(response.data);
      })
      .catch((error) => console.log(error.message));
  }, []);

  useEffect(() => {
    setDisplayedPro(
      products.filter((product) =>
        product.title.toLowerCase().includes(searchText.toLowerCase())
      )
    );
  }, [searchText]);

  return (
    <>
      <Router>
        <NavBar
          products={products}
          setDisplayedPro={setDisplayedPro}
          searchText={searchText}
          setSearchText={setSearchText}
        />
        <Routes>
          <Route
            exact
            path="/"
            element={
              <MainSeaction
                displayedPro={displayedPro}
                products={products}
                setProducts={setProducts}
              />
            }
          />
          <Route
            exact
            path="/cart"
            element={
              <CartSetion
                products={products}
                setProducts={setProducts}
                cartItems={cartItems}
                setCartItems={setCartItems}
                sumPrice={sumPrice}
              />
            }
          />
        </Routes>
      </Router>
    </>
  );
}

export default App;
