import React from "react";
import { Link } from "react-router-dom";
function Home({ products, setDisplayedPro }) {
  return (
    <Link style={{ textDecoration: "none" }} to="/">
      <button
        className="nav-link"
        style={{ cursor: "pointer" }}
        onClick={() => {
          setDisplayedPro([...products]);
        }}
      >
        Home
      </button>
    </Link>
  );
}

export default Home;
