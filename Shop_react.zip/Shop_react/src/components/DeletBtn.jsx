import React, { useState } from "react";

function DeletBtn({ id, products, setProducts }) {
  const [deletImage, setDeletImage] = useState("src/images/delete-icone.png");
  const deletIteamHandler = () => {
    setProducts(
      products.map((product) => {
        if (product.id === id) return { ...product, qty: 0 };
        return product;
      })
    );
  };
  return (
    <button
      className="btn"
      onMouseEnter={() => setDeletImage("src/images/delete-red-buttone.png")}
      onMouseLeave={() => setDeletImage("src/images/delete-icone.png")}
      onClick={deletIteamHandler}
    >
      <img src={deletImage} alt="" style={{ width: "30px" }} />
    </button>
  );
}

export default DeletBtn;
