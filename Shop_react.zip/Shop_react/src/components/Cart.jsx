import React, { useMemo } from "react";
import { Link } from "react-router-dom";
function Cart({ products }) {
  const numberInCart = useMemo(() => {
    let sumnbr = 0;
    for (let i = 0; i < products.length; i++) {
      sumnbr += products[i].qty;
    }
    return sumnbr;
  });
  return (
    <>
      <Link to="/cart">
        <div className="nav-link me-1 mb-sm-0">
          <img src="src\images\shop-icon.png" alt="My cart" />
        </div>
      </Link>
      <div className="text-light">{numberInCart}</div>
    </>
  );
}

export default Cart;
