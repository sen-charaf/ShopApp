import React from "react";

function SearchZone({ searchText, setSearchText }) {
  return (
    <form className="d-flex" role="search">
      <input
        className="form-control ms-4 me-0"
        type="search"
        placeholder="Search"
        aria-label="Search"
        value={searchText}
        onChange={(e) => setSearchText(e.target.value)}
      />
    </form>
  );
}

export default SearchZone;
