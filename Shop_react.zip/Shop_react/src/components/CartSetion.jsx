import React, { useEffect } from "react";
import CartItem from "./CartItem";

function CartSetion({
  products,
  setProducts,
  cartItems,
  setCartItems,
  sumPrice,
}) {
  useEffect(() => {
    setCartItems(products.filter((item) => item.qty !== 0));
  }, [products]);
  return (
    <>
      <div className="container text-center  bg-secondary rounded  w-50">
        {cartItems.map((item) => (
          <CartItem
            key={item.id * 10}
            id={item.id}
            title={item.title}
            price={item.price}
            image={item.image}
            qty={item.qty}
            products={products}
            setProducts={setProducts}
          />
        ))}
      </div>
      <div className="container text-center">
        <div>sum total: {sumPrice} $ </div>
        <button className="btn btn-outline-success ">Purchase</button>
      </div>
    </>
  );
}

export default CartSetion;
