import React from "react";

function Product({ id, title, price, image, products, setProducts }) {
  const addQtyHandler = () => {
    setProducts(
      products.map((item) => {
        if (item.id === id) return { ...item, qty: item.qty + 1 };
        return item;
      })
    );
  };
  return (
    <div className="card  mt-3 mb-3 ms-5 me-3" style={{ width: "250px" }}>
      <img
        src={image}
        style={{ height: "296.983px" }}
        className="card-img-top"
        alt="..."
      />
      <div className="card-body">
        <h5 className="card-title">{price}$</h5>
        <p className="card-text" style={{ height: "144px" }}>
          {title}
        </p>
        <button
          className="btn btn-primary"
          type="button"
          onClick={addQtyHandler}
        >
          Add to cart
        </button>
      </div>
    </div>
  );
}

export default Product;
