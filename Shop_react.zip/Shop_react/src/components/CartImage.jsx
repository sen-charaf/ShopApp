import React from "react";

function CartImage({ image }) {
  return (
    <div className="col-md-4 d-flex justify-content-center align-items-center">
      <img
        style={{ height: "50px" }}
        src={image}
        className="img-fluid rounded-start"
        alt="..."
      />
    </div>
  );
}

export default CartImage;
