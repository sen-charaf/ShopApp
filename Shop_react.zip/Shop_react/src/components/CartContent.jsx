import React from "react";
import DeletBtn from "./DeletBtn";

function CartContent({ id, price, qty, products, setProducts }) {
  return (
    <>
      <div className="card-text d-flex justify-content-around align-items-center ">
        <div>Qty: {qty}</div>
        <div> price: {price * qty}$</div>
        <DeletBtn id={id} products={products} setProducts={setProducts} />
      </div>
    </>
  );
}

export default CartContent;
