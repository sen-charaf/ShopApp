import React from "react";
import Product from "./Product";

function MainSeaction({ displayedPro, products, setProducts }) {
  return (
    <>
      <div className="row" style={{ width: "100%" }}>
        {displayedPro.map((product) => (
          <Product
            key={product.id - 1}
            id={product.id}
            title={product.title}
            price={product.price}
            image={product.image}
            products={products}
            setProducts={setProducts}
          />
        ))}
      </div>
    </>
  );
}

export default MainSeaction;
