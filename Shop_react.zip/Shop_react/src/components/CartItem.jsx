import React from "react";
import CartImage from "./CartImage";
import CartContent from "./CartContent";

function CartItem({ id, title, price, image, qty, products, setProducts }) {
  return (
    <div
      className="card mb-3 ms-4 h-30"
      style={{ maxWidth: "540px", height: "150.2px" }}
    >
      <div className="row g-0">
        <CartImage image={image} />
        <div className="col-md-8">
          <div className="card-body">
            <h5 className="card-title fs-6">{title}</h5>
            <CartContent
              id={id}
              price={price}
              qty={qty}
              products={products}
              setProducts={setProducts}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default CartItem;
